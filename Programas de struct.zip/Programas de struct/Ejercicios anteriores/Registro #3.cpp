#include <iostream>
using namespace std;

struct pais 
{
    string nombre;
    int cantidadhab;
};

int main() {
    // Definir tres variables de tipo pa�s
    pais paises[3];

    // Almacenar los nombres y la cantidad de habitantes de los pa�ses
    for (int i = 0; i < 3; i++) {
        cout << "Ingrese el nombre del pa�s " << i + 1 << ": ";
        cin >> paises[i].nombre;
        cout << "Ingrese la cantidad de habitantes del pa�s " << i + 1 << ": ";
        cin >> paises[i].cantidadhab;
    }

    // Encontrar el pa�s con la mayor cantidad de habitantes
    int maxHabitantes = paises[0].cantidadhab;
    string paisConMasHabitantes = paises[0].nombre;

    for (int i = 1; i < 3; i++) {
        if (paises[i].cantidadhab > maxHabitantes) {
            maxHabitantes = paises[i].cantidadhab;
            paisConMasHabitantes = paises[i].nombre;
        }
    }

    // Mostrar el nombre del pa�s con mayor cantidad de habitantes
    cout << "El pa�s con la mayor cantidad de habitantes es: " << paisConMasHabitantes << endl;

    return 0;
}

