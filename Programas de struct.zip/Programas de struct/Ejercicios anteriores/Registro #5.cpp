#include <iostream>
using namespace std;

struct Empleado
{
    string nombreCompleto;
    string direccion;
    string telefono;
    string cargo;
    double sueldo;
};

int main() {
    Empleado empleado; // Declaraci�n de una variable de tipo Empleado

    // Capturar los datos del empleado
    cout << "Ingrese el nombre completo del empleado: ";
    getline(cin, empleado.nombreCompleto);

    cout << "Ingrese la direcci�n del empleado: ";
    getline(cin, empleado.direccion);

    cout << "Ingrese el tel�fono del empleado: ";
    getline(cin, empleado.telefono);

    cout << "Ingrese el cargo del empleado: ";
    getline(cin, empleado.cargo);

    cout << "Ingrese el sueldo del empleado: ";
    cin >> empleado.sueldo;

    // Imprimir los datos del empleado
    cout << "\nDatos del empleado:" << endl;
    cout << "Nombre completo: " << empleado.nombreCompleto << endl;
    cout << "Direcci�n: " << empleado.direccion << endl;
    cout << "Tel�fono: " << empleado.telefono << endl;
    cout << "Cargo: " << empleado.cargo << endl;
    cout << "Sueldo: $" << empleado.sueldo << endl;

    return 0;
}

