#include <iostream>
using namespace std;

struct Producto 
{
    int codigo;
    string descripcion;
    double precio;
};

int main() {
    // Definir dos variables de tipo Producto
    Producto producto1, producto2;

    // Cargar informaci�n para el primer producto
    cout << "Ingrese el c�digo del primer producto: ";
    cin >> producto1.codigo;
    cout << "Ingrese la descripci�n del primer producto: ";
    cin.ignore(); // Para evitar problemas con getline despu�s de cin
    getline(cin, producto1.descripcion);
    cout << "Ingrese el precio del primer producto: ";
    cin >> producto1.precio;

    // Cargar informaci�n para el segundo producto
    cout << "Ingrese el c�digo del segundo producto: ";
    cin >> producto2.codigo;
    cout << "Ingrese la descripci�n del segundo producto: ";
    cin.ignore();
    getline(cin, producto2.descripcion);
    cout << "Ingrese el precio del segundo producto: ";
    cin >> producto2.precio;

    // Determinar el producto con el menor precio
    string productoConMenorPrecio;

    if (producto1.precio < producto2.precio) {
        productoConMenorPrecio = producto1.descripcion;
    } else {
        productoConMenorPrecio = producto2.descripcion;
    }

    // Mostrar el nombre del producto con menor precio
    cout << "El producto con menor precio es: " << productoConMenorPrecio << endl;

    return 0;
}

