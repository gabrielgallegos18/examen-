#include <iostream>
#include <ctime>

using namespace std;

// Definici�n de la estructura para la fecha y hora
struct FechaHora {
    int dia;
    int mes;
    int anio;
    int hora;
    int minuto;
    int segundo;
};

// Definici�n de la estructura para las operaciones financieras
struct OperacionFinanciera {
    int numeroCuenta;
    double cantidadDinero;
    int tipoOperacion; // 1 para dep�sito, 2 para retiro, 3 para estado de cuenta
    FechaHora fechaHora;
};

int main() {
    OperacionFinanciera operacion;

    // Ingresar datos de la operaci�n
    cout << "N�mero de cuenta: ";
    cin >> operacion.numeroCuenta;
    cout << "Cantidad de dinero: ";
    cin >> operacion.cantidadDinero;
    cout << "Tipo de operaci�n (1=Dep�sito, 2=Retiro, 3=Estado de cuenta): ";
    cin >> operacion.tipoOperacion;

    // Obtener la fecha y hora actual
    time_t now = time(0);
    tm* localTime = localtime(&now);
    operacion.fechaHora.dia = localTime->tm_mday;
    operacion.fechaHora.mes = localTime->tm_mon + 1; // tm_mon es de 0 a 11
    operacion.fechaHora.anio = localTime->tm_year + 1900; // A�o actual
    operacion.fechaHora.hora = localTime->tm_hour;
    operacion.fechaHora.minuto = localTime->tm_min;
    operacion.fechaHora.segundo = localTime->tm_sec;

    // Imprimir los datos de la operaci�n
    cout << "\nDatos de la operaci�n financiera:\n";
    cout << "N�mero de cuenta: " << operacion.numeroCuenta << endl;
    cout << "Cantidad de dinero: " << operacion.cantidadDinero << endl;
    cout << "Tipo de operaci�n: ";
    switch (operacion.tipoOperacion) {
        case 1:
            cout << "Dep�sito" << endl;
            break;
        case 2:
            cout << "Retiro" << endl;
            break;
        case 3:
            cout << "Estado de cuenta" << endl;
            break;
        default:
            cout << "Tipo de operaci�n no v�lida" << endl;
    }
    cout << "Fecha y hora de la operaci�n: " << operacion.fechaHora.dia << "/" << operacion.fechaHora.mes << "/" << operacion.fechaHora.anio << " "
         << operacion.fechaHora.hora << ":" << operacion.fechaHora.minuto << ":" << operacion.fechaHora.segundo << endl;

    return 0;
}

