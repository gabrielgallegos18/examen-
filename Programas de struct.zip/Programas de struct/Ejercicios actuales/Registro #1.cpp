#include <stdio.h>

// Definici�n de la estructura infoartista
struct infoartista {
    char nombre[20];
    int edad;
};

// Definici�n de la estructura cantantes
struct cantantes {
    char nombre_cantante[20];
    struct infoartista edad_cantante;
    char titulo_del_disco[50];
    int numero_de_canciones;
};

// Definici�n de la estructura actores
struct actores {
    char nombre_actor[22];
    struct infoartista edad_actor;
    int numero_de_peliculas;
    long int clasificacion;
    char nombre_de_pelicula[50];
    char nombre_del_personaje[30];
    char titulo[30];
    char nombre_del_personaje_para_cada_novela[30];
};

int main() {
    struct cantantes cantante1;
    struct actores actor1;

    // Almacenar datos para el cantante
    printf("Ingrese el nombre del cantante: ");
    scanf("%s", cantante1.nombre_cantante);
    printf("Ingrese la edad del cantante: ");
    scanf("%d", &cantante1.edad_cantante.edad);
    printf("Ingrese el t�tulo del disco: ");
    scanf("%s", cantante1.titulo_del_disco);
    printf("Ingrese el n�mero de canciones: ");
    scanf("%d", &cantante1.numero_de_canciones);

    // Almacenar datos para el actor
    printf("Ingrese el nombre del actor: ");
    scanf("%s", actor1.nombre_actor);
    printf("Ingrese la edad del actor: ");
    scanf("%d", &actor1.edad_actor.edad);
    printf("Ingrese el n�mero de pel�culas: ");
    scanf("%d", &actor1.numero_de_peliculas);
    printf("Ingrese la clasificaci�n: ");
    scanf("%ld", &actor1.clasificacion);
    printf("Ingrese el nombre de la pel�cula: ");
    scanf("%s", actor1.nombre_de_pelicula);
    printf("Ingrese el nombre del personaje: ");
    scanf("%s", actor1.nombre_del_personaje);
    printf("Ingrese el t�tulo: ");
    scanf("%s", actor1.titulo);
    printf("Ingrese el nombre del personaje para cada novela: ");
    scanf("%s", actor1.nombre_del_personaje_para_cada_novela);

    // Imprimir datos del cantante
    printf("\nDatos del cantante:\n");
    printf("Nombre: %s\n", cantante1.nombre_cantante);
    printf("Edad: %d\n", cantante1.edad_cantante.edad);
    printf("T�tulo del disco: %s\n", cantante1.titulo_del_disco);
    printf("N�mero de canciones: %d\n", cantante1.numero_de_canciones);

    // Imprimir datos del actor
    printf("\nDatos del actor:\n");
    printf("Nombre: %s\n", actor1.nombre_actor);
    printf("Edad: %d\n", actor1.edad_actor.edad);
    printf("N�mero de pel�culas: %d\n", actor1.numero_de_peliculas);
    printf("Clasificaci�n: %ld\n", actor1.clasificacion);
    printf("Nombre de la pel�cula: %s\n", actor1.nombre_de_pelicula);
    printf("Nombre del personaje: %s\n", actor1.nombre_del_personaje);
    printf("T�tulo: %s\n", actor1.titulo);
    printf("Nombre del personaje para cada novela: %s\n", actor1.nombre_del_personaje_para_cada_novela);

    return 0;
}

